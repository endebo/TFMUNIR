setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")

----------------------------  Individuales

setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")

library(dplyr)
library(corrplot)
rm(list=ls())
sink()

# lectura fichero datos

#Fichero Dioxido de Nitr�geno
contaminante<-"NO2"
estacion<-"28079038"

#   OJO CON EL FILTRO DE ESTACION !!!!!!!!!
# fich = paste("Resultados/csv/res",contaminante,".csv",sep="")
fich =  paste("Resultados/NO2CC/Estudios predicciones/ficheros/fich_",estacion,"_",contaminante,".csv",sep="")
fich2 =  paste("Resultados/NO2CC/Estudios predicciones/ficheros/fichent_",estacion,"_",contaminante,".csv",sep="")


dtDatos<-readr::read_delim(fich,delim=";",col_names = T )
dtDatos2<-readr::read_delim(fich2,delim=";",col_names = T )
dtDatos2$valor<-dtDatos$valor
dtDatos<-dtDatos[,-11]

dtDatos<-as.data.frame(dtDatos[dtDatos$estacion==estacion,])

clases<-dtDatos %>% group_by(valorcat) %>% summarise(count=n())
clases

nrow(dtDatos)

summary(dtDatos$valor)

t<-table(dtDatos$valorcat)
yl<- max(t)
yl

barplot(table(dtDatos$valorcat),xlab="Clases",ylab="N� Registros",ylim=c(0,yl),col=c("green","yellow","orange","red"))


boxplot(dtDatos$valor,data=dtDatos)



# ------------------------- regresion
fit <- lm(valor~tmed+prec+vmed+lluvia+intensidad+as.numeric(numsem)+diasem,data=dtDatos)
summary(fit)

par(mfrow=c(2,2))
plot(fit)

# ------------------------- correlaciones
kk<-cbind(dplyr::select(dtDatos,valor,tmed,prec,vmed,diasem,intensidad),numsem=as.integer(dtDatos$numsem))
c1<-cor(kk,use="all.obs")
corrplot(c1,method="number")

# ------------------------- correlaciones fichero normalizado
kk<-cbind(dplyr::select(dtDatos,valor,numsemZ,diasemZ,tmedZ,vmedZ,lluviaZ,tmed1Z,vmed1Z,intensidad1Z,valor1Z,lluvia1Z))
c1<-cor(kk,use="all.obs")
corrplot(c1,method="number")
plot(c1)




# Calculate Relative Importance for Each Predictor
library(relaimpo)
calc.relimp(fit,type=c("lmg","last","first","pratt"),
            rela=TRUE)


# Valor - dia semana

f1 <- lm(valor~diasem,data=dtDatos)
summary(f1)
plot(dtDatos$diasem,dtDatos$valor)
abline(f1)


#-------------------------------------------------------------------


library(dplyr)

#Fichero Dioxido de Nitr�geno
# contaminante<-"PM10"
options(digits=7)
rm(list=ls())
contaminante<-"O3"
# CO mg resto microgramos
#estacion<-"28079011"

fich = paste("Resultados/csv/res",contaminante,".csv",sep="")

nrow(dtDatos)

dtDatos<-readr::read_delim(fich,delim=";",col_names = T )

valores<- subset(dtDatos,select = c("estacion","valor"))

boxplot(valores$valor~valores$estacion,data=valores, main=paste(contaminante, "por estaci�n"), 
#        xlab="", ylab="mg/m3",las=2)
      xlab="", ylab=expression(paste(mu,"/m3",sep="")),las=2)

nrow(dtDatos)

summary(valores$valor)

t<-table(dtDatos$valorcat)
t


barplot(table(dtDatos$valorcat),xlab="Clases",ylab="N� Registros",ylim=c(0,8600),col=c("green","yellow","orange","red"))




# valores2<-valores[valores$valor>51,]
# boxplot(valores2$valor)
# summary(valores2$valor)

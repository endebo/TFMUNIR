# ----------------------------  graficos de lineas 2016
rm(list=ls())
SO2 <-  read.table("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK/Resultados/Estudios predicciones/Distribuciones/resSO2.csv",
                   header=TRUE, sep=";", na.strings="NA", dec=".", strip.white=TRUE)
SO2_2016 <- subset(SO2, subset=fecha>20160000 & fecha<20170000)   
SO2_2016_038 <- subset(SO2_2016, subset=estacion==28079038)

clases<-c(3,5,8,15)
meses<-c("ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic")
tick<-seq(20160100,20161200,100)
graphics.off()
par(fig=c(0,0.9,0,1),new=T)
plot(SO2_2016_038$fecha,SO2_2016_038$valor,type="l",
     xlab="mes", ylab="valor", main="Evoluci�n SO2 2016",xaxt="n",col="darkblue")
axis(side=1,labels=meses,at=tick)
abline(h=clases,col=alpha(c("green","yellow","orange","red"),0.5))
par(fig=c(0.70,1,0,1),new=T)
boxplot(SO2_2016_038$valor,axes=F)


rm(list=ls())
NO2 <-  read.table("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK/Resultados/Estudios predicciones/Distribuciones/resNO2.csv",
                   header=TRUE, sep=";", na.strings="NA", dec=".", strip.white=TRUE)
NO2_2016 <- subset(NO2, subset=fecha>20160000 & fecha<20170000)   
NO2_2016_038 <- subset(NO2_2016, subset=estacion==28079038)

clases<-c(23,36,51,100)
meses<-c("ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic")
tick<-seq(20160100,20161200,100)
graphics.off()
par(fig=c(0,0.9,0,1),new=T)
plot(NO2_2016_038$fecha,NO2_2016_038$valor,type="l",
     xlab="mes", ylab="valor", main="Evoluci�n NO2 2016",xaxt="n",col="darkblue")
axis(side=1,labels=meses,at=tick)
abline(h=clases,col=alpha(c("green","yellow","orange","red"),0.5))
par(fig=c(0.70,1,0,1),new=T)
boxplot(NO2_2016_038$valor,axes=F)

--------  PM10
rm(list=ls())
PM10 <-  read.table("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK/Resultados/Estudios predicciones/Distribuciones/resPM10.csv",
                    header=TRUE, sep=";", na.strings="NA", dec=".", strip.white=TRUE)
PM10_2016 <- subset(PM10, subset=fecha>20160000 & fecha<20170000)   
PM10_2016_038 <- subset(PM10_2016, subset=estacion==28079038)

clases<-c(12,18,26,250)
meses<-c("ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic")
tick<-seq(20160100,20161200,100)
graphics.off()
par(fig=c(0,0.9,0,1),new=T)
plot(PM10_2016_038$fecha,PM10_2016_038$valor,type="l",
     xlab="mes", ylab="valor", main="Evoluci�n PM10 2016",xaxt="n",col="darkblue")
axis(side=1,labels=meses,at=tick)
abline(h=clases,col=alpha(c("green","yellow","orange","red"),0.5))
par(fig=c(0.70,1,0,1),new=T)
boxplot(PM10_2016_038$valor,axes=F)

--------  PM25
rm(list=ls())
PM25 <-  read.table("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK/Resultados/Estudios predicciones/Distribuciones/resPM25.csv",
                    header=TRUE, sep=";", na.strings="NA", dec=".", strip.white=TRUE)
PM25_2016 <- subset(PM25, subset=fecha>20160000 & fecha<20170000)   
PM25_2016_038 <- subset(PM25_2016, subset=estacion==28079038)

clases<-c(7,10,14,60)
meses<-c("ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic")
tick<-seq(20160100,20161200,100)
graphics.off()
par(fig=c(0,0.9,0,1),new=T)
plot(PM25_2016_038$fecha,PM25_2016_038$valor,type="l",
     xlab="mes", ylab="valor", main="Evoluci�n PM25 2016",xaxt="n",col="darkblue")
axis(side=1,labels=meses,at=tick)
abline(h=clases,col=alpha(c("green","yellow","orange","red"),0.5))
par(fig=c(0.70,1,0,1),new=T)
boxplot(PM25_2016_038$valor,axes=F)
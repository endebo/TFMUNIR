setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")

library(dplyr)
library(scales)
library(mxnet)
rm(list=ls())
options(digits=15)

rounds<-500

# test<-as.data.frame(readr::read_delim("resultados/test.csv",delim=";",col_names = T ))
# colcat<-grep("valorcat",colnames(test))

dtSalida <- data.frame(fecha=numeric(),estacion=character,contaminante=character(),clase=numeric(),stringsAsFactors = FALSE)

# Leo ficheros carpeta predicciones
ficheros <- list.files("resultados/Predicciones/", pattern="*.csv", full.names=TRUE)
for(fich in ficheros){
  print(fich)
  aux<-strsplit(gsub(".csv","",fich),"_")
  fichModelo<- paste("resultados/modelos/mod_",aux[[1]][2],"_",aux[[1]][3],sep="")
  fichEscalado<- paste("resultados/escalado/esc_",aux[[1]][2],"_",aux[[1]][3],".csv",sep="")
  
  # Escalado

  escala<-function(dat){
    scaleValues<-read.delim(fichEscalado,sep=";",stringsAsFactors = F)
    for (col in colnames(dat)){
     
      nueZ <- paste(col,"Z",sep="")
      snc<-paste(col,"_CEN",sep="")
      sns<-paste(col,"_SCA",sep="")
      c<-as.numeric(scaleValues[1,snc])
      s<-as.numeric(scaleValues[1,sns])
     
      escalado<-scale(as.numeric(dat[1,col]),c,s)   # escala los valores
      dat[nueZ]<-escalado
    }       
    return(dat)
  }
  
  dtDatos<-readr::read_delim(fich,delim=";",col_names = T )
  
  dtDatos<- cbind(dtDatos,
                  numsem=strftime(as.Date(as.character(dtDatos$fecha),format="%Y%m%d"),format="%W"),
                  diasem=strftime(as.Date(as.character(dtDatos$fecha),format="%Y%m%d"),format="%w"),stringsAsFactors=F)

  
  dtDatos1<-escala(dtDatos[,-1])
  dtDatos2<-dtZ<-cbind(dtDatos1[,grep("Z$",colnames(dtDatos1))])
  dtDatos2 %>%    select(numsemZ, diasemZ, everything()) -> dtDatos2
  dtDatosZ<-data.matrix(dtDatos2)
 
  model<-mx.model.load(fichModelo,rounds)
  
  preds1 <- predict(model,dtDatosZ)
  predicted_labels1 <- max.col(t(preds1)) -1
  
  print(predicted_labels1)
  
  dtSalida<-rbind(dtSalida,data.frame(fecha=dtDatos$fecha,estacion=aux[[1]][2],contaminante=aux[[1]][3],clase=predicted_labels1))
}
write.table(dtSalida, "resultados/clases.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")

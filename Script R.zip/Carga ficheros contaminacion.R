setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")
# Carga librer�a Fast Access to Large ASCII Files.
library(LaF)
library(dplyr)
rm(list=ls())

# contaminantes a procesar SO2 CO NO NO2 PM25 PM10 O3 
contaminantes <- c("01","06","07","08","09","10","14")

# Define estructura del fichero
col_widths<-c(8,2,2,2,2,2,rep(c(5,1),31))
col_types<-rep("character", length(col_widths))
col_types[seq(7,67,2)]<-"numeric"

# switch que indica si hay que crear o a�adir en el fichero de resultados
app=F

# bucle para leer los ficheros
for (n in 11:17){
 
  fich = paste("DatosCalidad/datos",n,".txt",sep="")
  
  print(fich)
  
  laF<- laf_open_fwf(fich, column_widths = col_widths, 
                     column_types=col_types)
  
  # Lee el fichero y lo mete en el dataframe datos     
  datos0<-laF[,]
  close(laF)
  
  # Elimino registros de contaminantes que no se van a tratar
  datos <- filter(datos0, datos0$V2 %in% contaminantes)  
  
  # le a�ade al principio una columna con el n�mero de registro parea luego poder ordenar
  # cuando se duplique 31 veces las claves para convertir el registro seguido en uno por d�a del mes.
  datos <- cbind(Id=seq.int(nrow(datos)),datos)
  
  # Mete en matrices las columnas con los datos diarios y el resultado de la medici�n v valido otro no valido 
  # obtiene la trasversa para ponerlos en modo "vertical"   
  ncoldat <- seq(8,68,2)
  ncolval  <- seq(9,69,2)
  # dia del mes
  dia<-seq(1:31)
  dat<-t(as.matrix(datos[,ncoldat]))
  val<-t(as.matrix(datos[,ncolval]))
  
  # repite las claves 31 veces uno por d�a del mes   
  clave<-datos[rep(row.names(datos),31),1:7]
  # lo ordena pos la secuencia que anterios
  clave<-clave[order(clave$Id),]
  # junta todos los ficheros
  resul1<-cbind(clave,dato=c(dat),valido=c(val),fecha=paste("20",clave$V5,clave$V6,c(formatC(dia,width=2,flag="0")),sep=""),stringsAsFactors=F)
  resul<-dplyr::select(resul1,fecha,V1,V2,dato,valido)
  colnames(resul)<-c("fecha","estacion","contaminante","valor","valido")
  
  # lo guarda en disco  
  write.table(resul, "Resultados/rescontamina.csv",row.names = F, col.names=!app,quote=F,append=app,sep=";",dec=".")
  app=T
  
}







setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")
library(dplyr)
library(readr)


rm(list=ls())


#fichero de contaminacion
dtContamina<-readr::read_delim("Resultados/rescontamina.csv",delim=";",col_names = T) # no lee bien loe decimales,col_types=cols(.default="c",valor="n"))
# filtra validos
dtContamina<-dtContamina[dtContamina$valido=="V",]
#fichero aemet
dtAemet<-readr::read_delim("Resultados/resaemet.csv",delim=";",col_names = T) #, col_types=cols(.default="n",fecha="c"))
#fichero trafico
dtTrafico<-readr::read_delim("Resultados/restrafico.csv",delim=";",col_names = T) #,col_types=cols(fecha="c",intensidad="i"))

# el fichero aemet tiene mas registros que el de tr�fico, junto left join aemet trafico por fecha

aemtraf <- dplyr::left_join(dtAemet,dtTrafico,by="fecha")

# junto con el fichero de contaminacion

conaemtraf <- dplyr::left_join(dtContamina,aemtraf,by="fecha")

# %w numero de dia de la semana 0 domingo %W numero de semana del a�o comenzando un lunes
result1 <- cbind(conaemtraf,mes=strftime(as.Date(as.character(conaemtraf$fecha),format="%Y%m%d"),format="%m"),
                 numsem=strftime(as.Date(as.character(conaemtraf$fecha),format="%Y%m%d"),format="%W"),
                 diasem=strftime(as.Date(as.character(conaemtraf$fecha),format="%Y%m%d"),format="%w"),stringsAsFactors=F)

# rm(dtContamina)
# rm(dtAemet)
# rm(dtTrafico)
# Elimino los nulos en el campo intensidad con la media de los valores para el mes y dia de la semana
# dataframe con las medias de intensidad por mes y dia de la semana
mediaIntensidad<-as.data.frame(result1%>%group_by(mes,diasem)%>% dplyr::summarise(intensidad=round(mean(intensidad,na.rm = T),0)))


quitanulos<-function(x){
  
  if(is.na(x["intensidad"])){
    
    i<-mediaIntensidad[(mediaIntensidad$mes==x["mes"] & mediaIntensidad$diasem==x["diasem"]),]$intensidad
    return (as.numeric(i))

  }
  else{
    return (as.numeric(x["intensidad"]))
  }
  
}

result1$intensidad  <- apply(result1,1,quitanulos)


                  # valor2=lag(valor,n=2),
                  # tmed2=lag(tmed,n=2),
                  # prec2=lag(prec,n=2),
                  # vmed2=lag(vmed,n=2),
                  # intensidad2=lag(intensidad,n=2),
                  # valor3=lag(valor,n=3),
                  # prec3=lag(prec,n=3),
                  # tmed3=lag(tmed,n=3),
                  # vmed3=lag(vmed,n=3),
                  # intensidad3=lag(intensidad,n=3))



# escalaynormaliza<-function(dat,campos){
# 
#   for (col in campos){
#     
#     # if (startsWith(col,"prec")){
#     #   print(dat[,col])
#     #   c<-as.numeric(dat[,col])*100
#     # }
#     # if (startsWith(col,"inten")){
#     #   print(dat[,col])
#     #   c<-as.numeric(dat[,col])*200
#     # }
#     
#     nueS <- paste(col,"S",sep="")
#     nueZ <- paste(col,"Z",sep="")
#     dat[nueS]<-rescale(as.numeric(dat[,col])) # escala a intervalo [0.1]
#     dat[nueZ]<-as.numeric(scale(as.numeric(dat[,col])))   # normaliza los valores
#    # dat[nueZ]<-rescale(as.numeric(dat[,col]),to=c(-1,1))   # normaliza los valores
#   }
#   
#   # if (startsWith(col,"prec")){
#   #  dat[nueZ]<-dat[nueZ] + 1
#   # }
#  
#   return(dat)
# }
# 
# colscalar<-c("numsem","diasem",
#              "valor1","valor2","valor3",
#              "tmed","prec","vmed","intensidad",
#             "tmed1","prec1","vmed1","intensidad1",
#             "tmed2","prec2","vmed2","intensidad2",
#             "tmed3","prec3","vmed3","intensidad3")
# 
# 
# result3<-escalaynormaliza(result2,colscalar)

# elimino los tres primeros registros con nulos en los campos de los d�as anteriores




# categorizacion contaminaci�n
# 1-Buena, 2-Admisible 3-Deficiente 4-Mala
# calidad<-c("1","2","3","4","5")
# calidad<-c(0,0.2,0.4,0.6,0.8)
calidad<-c(1,2,3,4)

# valores segun contaminante valores seg�n Ayto de Madrid

# fichero SO2
# valSO2_01  = c(0,175,350,525,Inf)
# sin extremos valSO2_01  = c(0,3,5,8,16,Inf)
valSO2_01  = c(0,3,5,8,Inf)
datSO2 <- result1[result1$contaminante=="01",]
datSO2$valorcat <-  cut(as.numeric(datSO2$valor),breaks=valSO2_01,labels = calidad,right = F)
write.table(datSO2, "resultados/csv/resSO2.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")



# fichero CO
# valCO_06   = c(0,5,10,15,Inf)
# sin extremos valCO_06   = c(0,0.2,0.3,0.4,0.7,Inf)
valCO_06   = c(0,0.2,0.3,0.4,Inf)
datCO <- result1[result1$contaminante=="06",]
datCO$valorcat <-  cut(as.numeric(datCO$valor),breaks=valCO_06,labels = calidad,right = F)

write.table(datCO, "resultados/csv/resCO.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")

# fichero NO
# valNO_07  = c(0,100,200,300,Inf)
# sin extremos valNO_07  = c(0,5,11,27,60,Inf)
valNO_07  = c(0,5,11,27,Inf)
datNO <- result1[result1$contaminante=="07",]
datNO$valorcat <-  cut(as.numeric(datNO$valor),breaks=valNO_07,labels = calidad,right = F)

write.table(datNO, "resultados/csv/resNO.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")


# fichero NO2
# valNO2_08  = c(0,100,200,300,Inf)
# sin extremos valNO2_08  = c(0,23,36,51,93,Inf)
valNO2_08  = c(0,23,36,51,Inf)
# siguiente valores para estacion de CC
# valNO2_08  = c(0,33,47,57,Inf)
# valNO2_08  = c(0,30,42,56,Inf)
datNO2 <- result1[result1$contaminante=="08",]
datNO2$valorcat <-  cut(as.numeric(datNO2$valor),breaks=valNO2_08,labels = calidad,right = F)

write.table(datNO2, "resultados/csv/resNO2.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")


# fichero PM25
# valPM25_09  = c(0,100,200,300,Inf)
# sin extremos valPM25_09  = c(0,7,10,14,25,Inf)
valPM25_09  = c(0,7,10,14,Inf)
datPM25 <- result1[result1$contaminante=="09",]
datPM25$valorcat <-  cut(as.numeric(datPM25$valor),breaks=valPM25_09,labels = calidad,right = F)

write.table(datPM25, "resultados/csv/resPM25.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")



# fichero PM10
# valPM10_10 = c(0,50,90,150,Inf)
# sin extremos valPM10_10 = c(0,12,18,26,47,Inf)
valPM10_10 = c(0,12,18,26,Inf)

datPM10 <- result1[result1$contaminante=="10",]
datPM10$valorcat <-  cut(as.numeric(datPM10$valor),breaks=valPM10_10,labels = calidad,right = F)
write.table(datPM10, "resultados/csv/resPM10.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")

# # fichero NOX ----------------------- no hay medidas
# # No hay valores de referencia
# valNOX_12 = c(0,1,2,3,Inf)
# 
# datNOX <- result1[result1$contaminante=="12",]
# datNOX$valorcat <-  cut(as.numeric(datNOX$valor),breaks=valNOX_12,labels = calidad,right = F)
# write.table(datNOX, "resultados/csv/resNOX.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")


# fichero O3
# v alO3_14   = c(0,90,180,240,Inf
# sin extremos valO3_14   = c(0,29,49,66,122,Inf)
valO3_14   = c(0,29,49,66,Inf)
datO3 <- result1[result1$contaminante=="14",]
datO3$valorcat <-  cut(as.numeric(datO3$valor),breaks=valO3_14,labels = calidad,right = F)


write.table(datO3, "resultados/csv/resO3.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")

# hist(as.numeric(datNO2$valor),breaks = seq(0,500,by=20))











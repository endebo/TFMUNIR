setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")

library(dplyr)
rm(list=ls())
sink()

# lectura fichero datos

#Fichero Dioxido de Nitr�geno
contaminante<-"PM25"
estacion<-"28079024"

fich = paste("Resultados/csv/res",contaminante,".csv",sep="")
# fich =  paste("Resultados/Estudios predicciones/ficheros/fich_",estacion,"_",contaminante,".csv",sep="")

dtDatos<-readr::read_delim(fich,delim=";",col_names = T )
dtDatos<-dtDatos[dtDatos$estacion==estacion,]

# cor(dtDatos)

# fit <- lm(valorcat~.,data=dtDatos)
fit <- lm(valor~tmed+prec+vmed+lluvia+intensidad+as.numeric(numsem)+diasem,data=dtDatos)
summary(fit)

par(mfrow=c(2,2))
plot(fit)


# dtDatosE<-dtDatos[dtDatos$estacion==estacion,]


# fit1 <- lm(valor~tmed+prec+vmed+intensidad,data=dtDatosE)
# http://www.statmethods.net/stats/regression.html

summary(fit1)
coefficients(fit1)
fitted(fit1)
residuals(fit1)
anova(fit1)
influence(fit1)


layout(matrix(c(1,2,3,4),2,2)) # optional 4 graphs/page 
plot(fit1)

# # compare models
fit1 <- lm(y ~ x1 + x2 + x3 + x4, data=mydata)
fit2 <- lm(y ~ x1 + x2)
anova(fit1, fit2)

# K-fold cross-validation
dt=as.data.frame(dtDatosE)
library(DAAG)
cv.lm(data=dt, fit1, m=4) # 3 fold cross-validation

library(MASS)
dt=as.data.frame(dtDatosE)
fit <- lm(valor~tmedZ+precZ+vmedZ+intensidadZ,data=dt)
step<-stepAIC(fit,direction = "both")
step$anova 


# All Subsets Regression
library(leaps)
attach(dt)
leaps<-regsubsets(valor~tmedZ+precZ+vmedZ+intensidadZ,data=dt,nbest=10)
# view results 
summary(leaps)
# plot a table of models showing variables in each model.
# models are ordered by the selection statistic.
plot(leaps,scale="r2")
# plot statistic by subset size 
library(car)
subsets(leaps, statistic="rsq")


# Calculate Relative Importance for Each Predictor
library(relaimpo)
calc.relimp(fit,type=c("lmg","last","first","pratt"),
            rela=TRUE)

# Bootstrap Measures of Relative Importance (1000 samples) 
boot <- boot.relimp(fit, b = 700, type = c("lmg", 
                                            "last", "first", "pratt"), rank = TRUE, 
                    diff = TRUE, rela = TRUE)
booteval.relimp(boot) # print result
plot(booteval.relimp(boot,sort=TRUE)) # plot result



# val_tmed <- subset(dtDatosE,select = c("valor","tmed"))
# val_tmed <- cbind(dtDatosE$valor,dtDatosE$tmed)
attach(dtDatosE)
val.ex.prec <- subset(dtDatosE, select = c( "prec","valor"))
cor.test(valor,vmed)
plot(valor,vmed)

# 
# summary(val.ex.prec)
# cor(val.ex.prec)
# plot(val.ex.prec)
# 
# relTM<-lm(valor,tmed,data=dtDatosE)
# cor(as.numeric(dtDatosE$valor),as.numeric(dtDatosE$tmed))
# plot(dtDatosE$valor,dtDatosE$tmed,abline(relTM))

#http://tutorials.iq.harvard.edu/R/Rstatistics/Rstatistics.html

# Video regresion linear multiple con R 
fit2<-lm(valorcat~tmedZ+precZ+vmedZ+intensidadZ+
                tmed1Z+prec1Z+vmed1Z+intensidad1Z+
                tmed2Z+prec2Z+vmed2Z+intensidad2Z+
                tmed3Z+prec3Z+vmed3Z+intensidad3Z
         ,data=dtDatosE)
summary(fit2)

fit2$coefficients
fit2$residuals
fit2$fitted.values



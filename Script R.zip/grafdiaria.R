rm(list=ls())

estac<-"28079018"
contaminantes <- c("01","06","07","08","09","10","14")
contam<-14
contamlit <- "O3"
tbDatos <-  read.delim("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/MEMORIA/Graficos/Datosdiarios/predicciones.txt",
                   header=TRUE, sep=";", na.strings="NA", dec=".", strip.white=TRUE)

tbDatos<- subset(tbDatos, subset=estacion==estac)
tbDatos<- subset(tbDatos, subset=contaminante==contam)
graphics.off()
# par(fig=c(0,0.9,0,1),new=T)
tit<-paste("Estacion ", estac, " - Contaminante ", contamlit)
subtit<-"10/09/2017 a 16/09/2017"



  plot(tbDatos$fecha,tbDatos$clasreal,type="p",pch=10,cex=4,
       xlab="dia",ylab="clase", main=tit,col="darkblue",yaxt="n",ylim=c(1,4))
  axis(2,at=c(1,2,3,4),las=1)
  
  lines(tbDatos$fecha,tbDatos$claspred,type="p",col="red",pch=20,cex=2)
  legend(,legend=c("Prediccion","Real"),pch)

# axis(side=1,labels=meses,at=tick)
# abline(h=clases,col=alpha(c("green","yellow","orange","red"),0.5))
# par(fig=c(0.70,1,0,1),new=T)
# boxplot(SO2_2016_038$valor,axes=F)


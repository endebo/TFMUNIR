setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")

library(dplyr)

# lectura fichero datos
dtDatos<-readr::read_delim("Resultados/csv/resPM10.csv",delim=";",col_names = T )
# cuento ocurrencias de cada clase
clases<-dtDatos %>% group_by(valorcat) %>% summarise(count=n())
# cuento ocurrencias de cada clase por estacion
clasesEstacion<-dtDatos %>% group_by(estacion,valorcat) %>% summarise(count=n())

dtDatosE<-dtDatos[dtDatos$estacion==28079008,]

#dtZ<-cbind(dtDatos[,grep("Z$",colnames(dtDatos))],dtDatos[,"valorcat"])
dtZ<-cbind(dtDatosE[,grep("Z$",colnames(dtDatosE))],dtDatosE[,"valorcat"])
colcat<-19

# dtZ<-dtZ[,-grep("3Z$",colnames(dtZ))]
# colcat<-15
# dtZ<-dtZ[,-grep("2Z$",colnames(dtZ))]
# colcat<-11




# para que las particiones sean las mismas
set.seed(1)
indices<-sample(1:nrow(dtZ),round(0.75*nrow(dtZ)))

train<-dtZ[indices,]
test<-dtZ[-indices,]

# ------------------------------------

require(mxnet)



# train.x <- data.matrix(train[,-19])
# train.y <- train[,19]
# test.x <- data.matrix(test[,-19])
# test.y <- test[,19]

train.x <- data.matrix(train[,-colcat])
train.y <- train[,colcat]
test.x <- data.matrix(test[,-colcat])
test.y <- test[,colcat]

# train.x <- data.matrix(train[,-11])
# train.y <- train[,11]
# test.x <- data.matrix(test[,-11])
# test.y <- test[,11]

nodes<-100
lr<-0.8
mom<-0.9
rounds <-1000
batch<-200

mx.set.seed(1)
model <- mx.mlp(train.x, train.y, hidden_node=c(nodes), out_node=4,activation="sigmoid", out_activation="softmax",
                num.round=rounds, array.batch.size=batch, learning.rate=lr, momentum=mom, 
                eval.metric=mx.metric.accuracy)


clasesTest<-test %>% group_by(valorcat) %>% summarise(count=n())

#test 



preds <- predict(model,test.x)
predicted_labels <- max.col(t(preds)) - 1

accu <- sum(test.y==predicted_labels)/length(test.y)

print(paste0("Accurracy=",accu))





sprintf("nodos: %i  LR: %f Mom: %f Rounds:%i",nodes,lr,mom,rounds)
table(test.y,predicted_labels)

# dim(preds)




# data <- mx.symbol.Variable("data")
# fc1 <- mx.symbol.FullyConnected(data, num_hidden=12)
# act1 <- mx.symbol.Activation(fc1, name="relu1", act_type="relu")
# # fc2 <- mx.symbol.FullyConnected(act1, name="fc2", num_hidden=64)
# # act2 <- mx.symbol.Activation(fc2, name="relu2", act_type="relu") 
# fc3 <- mx.symbol.FullyConnected(act2, name="fc3", num_hidden=2)
# lro <- mx.symbol.SoftmaxOutput(fc3, name="sm") 
# model2 <- mx.model.FeedForward.create(lro, X=train.x, y=train.y, 
#         ctx=mx.cpu(), num.round=100, array.batch.size=15, learning.rate=0.07, momentum=0.9)








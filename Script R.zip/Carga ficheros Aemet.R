setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")
library(jsonlite)
library(dplyr)
estmadrid<-fromJSON("DatosAemet/EstacionesMadrid.json")
estmadridV <- as.vector(estmadrid$indicativo)
app=FALSE
nfich=0
for (a in 2011:2017){
  for (m in "01":"12"){
    
    fich = paste("DatosAemet/aemet",a,formatC(m,width=2,flag="0"),".json",sep="")
    
    if (file.exists(fich)){
      print(fich)
    datos<-fromJSON(fich)
    
    
    datos<-dplyr::filter(datos,datos$indicativo %in% estmadridV)
    
   
    datos$fecha <- gsub('-','',datos$fecha)
    
    datos2<-dplyr::select(datos,indicativo,fecha,tmed,prec,velmedia)
    datos2$tmed<-as.numeric(sub(',','.',datos2$tmed))
    datos2$prec<-as.numeric(sub(',','.',datos2$prec))
    datos2$velmedia<-as.numeric(sub(',','.',datos2$velmedia))
    
    datos3<-datos2 %>% dplyr::group_by(fecha) %>% dplyr::summarise(tmed=format(round(mean(tmed,na.rm = T),2),nsmall=2),
                                                                   prec=format(round(mean(prec,na.rm = T),2),nsmall=2),
                                                                   vmed=format(round(mean(velmedia,na.rm = T),2),nsmall=2))
    datos3$lluvia<-as.numeric(ifelse(as.numeric(datos3$prec)>0.2,1,0))
    write.table(datos3, "Resultados/resaemet.csv",row.names = F, col.names=!app,quote=F,append=app,sep=";",dec=".")
    app=T
    }
  }
}
setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")
library(dplyr)
# 
# memory.size()
# memory.profile()


#  #Unzip ficheros
# fichzip <- list.files("DatosTrafico/zip2/", pattern="*.zip", full.names=TRUE)
# 
# for (i in fichzip) {
#    print(i)
# 
#    unzip(i, overwrite = TRUE,list=F,
#                          exdir = "DatosTrafico/unzip", unzip = "internal",setTimes = FALSE)
# }


app=FALSE

fichlist <- list.files("DatosTrafico/unzip/", pattern="*.csv", full.names=TRUE)
nfich=0
for (a in 2013:2017){
  for (m in 1:12){
    fich = paste("DatosTrafico/unzip/",formatC(m,width=2,flag="0"),"-",a,".csv",sep="")
   if (file.exists(fich)){
     nfich = nfich + 1
 # for (fich in fichlist){
        print(fich);
  
        # datos<-readr::read_csv2(fich,col_types=
        #                         cols(
        #                           identif ="c",
        #                           fecha = col_datetime(format = "%Y%m%d"),
        #                           intensidad = "i",
        #                           ocupacion = "_", # col_skip()
        #                           carga = "_", # col_skip()
        #                           tipo = "_", # col_skip()
        #                           vmed = "_", # col_skip()
   
        #                           error ="c",
        #                           periodo_integracion ="_" # col_skip()
        #                         )
        #                        ) 
   
        datos<-readr::read_csv2(fich,col_names = T)
        
        # print(head(datos))
        # elimina lecturas incorrectas
        datos<-dplyr::filter(datos,error=='N')
      
        # elimina intensidades a 0
        datos<-dplyr::filter(datos,intensidad>0)
      
        # selecciona columna feha e intensidad
        datos<-dplyr::select(datos,fecha,intensidad)
     
        #formateo fecha yymmdd
        datos$fecha<-gsub('-','',as.character(as.Date(datos$fecha,"%Y%m%d")))
       
      #  datos3<-dplyr::filter(datos,fecha=="20170101")
        datos3<-datos %>% dplyr::group_by(fecha) %>% dplyr::summarise(intensidad=round(mean(intensidad,na.rm = T),0))
        # print("llega")
        # print(object_size(datos3))
        # print(mem_used())
 
        write.table(datos3, "Resultados/restrafico.csv",row.names = F, col.names=!app,quote=F,append=app,sep=";",dec=".")
        app=T
       
    }
   }
}
print(nfich)
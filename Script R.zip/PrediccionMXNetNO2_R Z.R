setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")

library(dplyr)
library(readr)
library(scales)

rm(list=ls())

contaminante<-"NO2"
nodes<-c(24)
lr<-0.01
mom<-0.9
rounds <-1000
batch<-100
fich = paste("Resultados/csv/res",contaminante,".csv",sep="")

#--------------------------------------------------------- NORMALIZA
escalaynormaliza<-function(dat,campos){
  for (col in campos){

    # if (startsWith(col,"prec")){
    #   print(dat[,col])
    #   c<-as.numeric(dat[,col])*100
    # }
    # if (startsWith(col,"inten")){
    #   print(dat[,col])
    #   c<-as.numeric(dat[,col])*200
    # }   
    # nueS <- paste(col,"S",sep="")
    # dat[nueS]<-rescale(as.numeric(dat[,col])) # escala a intervalo [0.1]
    
    nueZ <- paste(col,"Z",sep="")
    dat[nueZ]<-as.numeric(scale(as.numeric(dat[,col])))   # normaliza los valores
   # dat[nueZ]<-rescale(as.numeric(dat[,col]),to=c(-1,1))   # normaliza los valores
  }

  # if (startsWith(col,"prec")){
  #  dat[nueZ]<-dat[nueZ] + 1
  # }

  return(dat)
}

# en el fichero de predicciones no se dispone del volumen de precipitaci�n

colscalar<-c("numsem",
             "diasem",
             "tmed",
             # "prec",
             "vmed",
             "intensidad",
             "lluvia",
             "tmed1",
             # "prec1",
             "vmed1",
             "intensidad1",
             "valor1",
             "lluvia1")
             




#-----------------------------------------------------------------------------------


# lectura fichero datos
dtDatos<-readr::read_delim(fich,delim=";",col_names = T )
# cuento ocurrencias de cada clase
clases<-dtDatos %>% group_by(valorcat) %>% summarise(count=n())
# cuento ocurrencias de cada clase por estacion
clasesEstacion<-dtDatos %>% group_by(estacion,valorcat) %>% summarise(count=n())

# dtDatos<-dtDatos[dtDatos$valorcat<5,]
dtDatosE<-as.data.frame(dtDatos)
dtDatosE<-as.data.frame(dtDatos[dtDatos$estacion==28079018,])

dtDatosE <- mutate(dtDatosE,
                  valor1=lag(valor,n=1),
                  tmed1=lag(tmed,n=1),
                #  prec1=lag(prec,n=1),
                  vmed1=lag(vmed,n=1),
                  lluvia1=lag(lluvia,n=1),
                  intensidad1=lag(intensidad,n=1))
#                  valorant=lag(valorcat,n=1))
dtDatosE<-dtDatosE[-1,]

# write.table(dtDatosE, "resultados/csv/NO2Estacion.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")


dtDatosE<-escalaynormaliza(dtDatosE,colscalar)


# eliminio columnas 
# dtDatosE<-cbind(dtDatosE[,-grep("^inten",colnames(dtDatosE))])

# dtDatosE<- subset(dtDatosE,  select = c("intensidad","numsemZ","diasemZ"))
# dtDatosE[, c("intensidad","numsemZ","diasemZ","valorant2","valorant3")]<-NULL
# dtDatosE[,grep("^prec",colnames(dtDatosE))]<-NULL
# dtDatosE[,grep("^vmed",colnames(dtDatosE))]<-NULL
# dtDatosE[,grep("^tmed",colnames(dtDatosE))]<-NULL
# dtDatosE[,grep("^intensidad",colnames(dtDatosE))]<-NULL
# dtDatosE[,grep("^valorant",colnames(dtDatosE))]<-NULL
# dtDatosE$numsemZ<-NULL


clasesEstacion<-dtDatosE %>% group_by(estacion,valorcat) %>% summarise(count=n())

#dtZ<-cbind
# dtZ<-cbind(dtDatosE[,grep("Z$",colnames(dtDatosE))],dtDatosE[,"valorcat"])

dtZ<-cbind(dtDatosE[,grep("Z$",colnames(dtDatosE))],dtDatosE[,grep("^valorant",colnames(dtDatosE))],dtDatosE[,"valorcat"])

colcat<-grep("valorcat",colnames(dtZ))
# colcat<-15

# dtZ<-dtZ[,-grep("3Z$",colnames(dtZ))]
# colcat<-15
# dtZ<-dtZ[,-grep("2Z$",colnames(dtZ))]
# colcat<-11



# para que las particiones sean las mismas
set.seed(1)
indices<-sample(1:nrow(dtZ),round(0.75*nrow(dtZ)))

train<-dtZ[indices,]
test<-dtZ[-indices,]

# ------------------------------------

require(mxnet)


train.x <- data.matrix(train[,-colcat])
train.y <- train[,colcat]
test.x <- data.matrix(test[,-colcat])
test.y <- test[,colcat]


mx.set.seed(1)
model <- mx.mlp(train.x, train.y, hidden_node=c(nodes), out_node=5,activation="sigmoid", out_activation="softmax",
                num.round=rounds, array.batch.size=batch, learning.rate=lr, momentum=mom, 
                eval.metric=mx.metric.accuracy)

mx.model.save(model,"modelo",rounds)

clasesTest<-test %>% group_by(valorcat) %>% summarise(count=n())
#test 
preds <- predict(model,test.x)
predicted_labels <- max.col(t(preds)) -1
accu <- sum(test.y==predicted_labels)/length(test.y)

table(test.y,predicted_labels)
# dim(preds)
resul<-as.data.frame(cbind(test.x,test.y,predicted_labels))
resul$acierto<- resul$test.y==resul$predicted_labels

print(sprintf("nodos: %i  LR: %f Mom: %f Rounds:%i",nodes,lr,mom,rounds))
print(paste0("Accurracy=",accu))
print(sprintf("Aciertos:%i  Fallos:%i",nrow(resul[resul$acierto==T,]),nrow(resul[resul$acierto==F,])))

# data <- mx.symbol.Variable("data")
# fc1 <- mx.symbol.FullyConnected(data, num_hidden=12)
# act1 <- mx.symbol.Activation(fc1, name="relu1", act_type="relu")
# # fc2 <- mx.symbol.FullyConnected(act1, name="fc2", num_hidden=64)
# # act2 <- mx.symbol.Activation(fc2, name="relu2", act_type="relu") 
# fc3 <- mx.symbol.FullyConnected(act2, name="fc3", num_hidden=2)
# lro <- mx.symbol.SoftmaxOutput(fc3, name="sm") 
# model2 <- mx.model.FeedForward.create(lro, X=train.x, y=train.y, 
#         ctx=mx.cpu(), num.round=100, array.batch.size=15, learning.rate=0.07, momentum=0.9)








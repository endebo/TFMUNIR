setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")

library(dplyr)

# lectura fichero datos
dtDatos<-readr::read_csv2("Resultados/csv/resPM10_2.csv",col_names = T)
# cuento ocurrencias de cada clase
clases<-dtDatos %>% group_by(valorcat) %>% summarise(count=n())
# cuento ocurrencias de cada clase por estacion
clasesEstacion<-dtDatos %>% group_by(estacion,valorcat) %>% summarise(count=n())

dtDatosE<-dtDatos[dtDatos$estacion==28079008,]

#dtI<-cbind(dtDatos[,grep("Z$",colnames(dtDatos))],dtDatos[,"valorcat"])
dtI<-cbind(dtDatosE[,grep("I$",colnames(dtDatosE))],dtDatosE[,"valorcat"])



# para que las particiones sean las mismas
set.seed(1)
indices<-sample(1:nrow(dtI),round(0.75*nrow(dtI)))
train<-dtI[indices,]
test<-dtI[-indices,]

require(mxnet)
train.x <- data.matrix(train[,-19])
train.y <- train[,19]

model <- mx.mlp(train.x, train.y, hidden_node=c(100), out_node=4,activation="sigmoid", out_activation="softmax",
                num.round=1000, array.batch.size=32, learning.rate=0.07, momentum=0.8, 
                eval.metric=mx.metric.accuracy)


clasesTest<-test %>% group_by(valorcat) %>% summarise(count=n())

#test 
test.x <- data.matrix(test[,-19])
test.y <- test[,19]
preds <- predict(model,test.x)
predicted_labels <- max.col(t(preds)) - 1
table(test.y,predicted_labels)

# dim(preds)




# data <- mx.symbol.Variable("data")
# fc1 <- mx.symbol.FullyConnected(data, num_hidden=12)
# act1 <- mx.symbol.Activation(fc1, name="relu1", act_type="relu")
# # fc2 <- mx.symbol.FullyConnected(act1, name="fc2", num_hidden=64)
# # act2 <- mx.symbol.Activation(fc2, name="relu2", act_type="relu") 
# fc3 <- mx.symbol.FullyConnected(act2, name="fc3", num_hidden=2)
# lro <- mx.symbol.SoftmaxOutput(fc3, name="sm") 
# model2 <- mx.model.FeedForward.create(lro, X=train.x, y=train.y, 
#         ctx=mx.cpu(), num.round=100, array.batch.size=15, learning.rate=0.07, momentum=0.9)








##
# �������  OJOOOOOO NO ABRIR CSV CON EXCEL PROBLEMAS CON EL PUNTO DECIMAL !!!!!!!!!!!!!!

setwd("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/CALIDAD AIRE/TFT_RWRK")

library(dplyr)
library(readr)
# library(scales)
# detach("package:scales")

# ----------------- Borro ficheros
file.remove(file.path("resultados/NO2CC/modelos", list.files("resultados/modelos")))
file.remove(file.path("resultados/NO2CC/escalado", list.files("resultados/escalado")))


# sink("Resultados/NO2CC/salida.txt")



rm(list=ls())


# contaminantes <- c("SO2","CO","NO","NO2","PM25","PM10","O3")
contaminantes <- c("NO2")
# contaminantes <- c("SO2")
# estaciones<-c("28079024")
estaciones<-c("28079038")


# en el fichero de predicciones no se dispone del volumen de precipitaci�n, elimino campo prec

colscalar<-c(
            "numsem",
            "diasem",
             "tmed",
            "vmed",
            "lluvia",
            "tmed1",
         "vmed1",
            "intensidad1",
             "valor1",
           "lluvia1"
             )


        
# Preparo dataframe para guardar los par�metros de escalado
# dtEscalado<-as.data.frame(contaminantes,stringsAsFactors = F)
# dtEscalado<-data.frame(stringsAsFactors = F)
# colnames(dtEscalado)<-c("cont")
dtEscalado<- setNames(data.frame(matrix(ncol = 1, nrow = 1)), c("cont"))
for (col in colscalar){
  colcen <- paste(col,"_CEN",sep="")
  colsca <- paste(col,"_SCA",sep="")
  dtEscalado[colcen]<-double()
  dtEscalado[colsca]<-double()
}

# contam<-"SO2"
# colcen="numsem_CEN"
# 
# dtEscalado[dtEscalado$cont==contam,colcen]<-9



# Pongo este bucle fuera para poder escribir un fichero con los datos de escalado por estaci�n
for (contam in contaminantes){
  nodes<-c(10)
  lr<-0.05
  mom<-0.8
  rounds <-5000
  act<-"relu"
  batch<-100
  fich = paste("Resultados/csv/res",contam,".csv",sep="")
  dtEscalado$cont<-contam
  
  # model <- mx.mlp(train.x, train.y, hidden_node=c(nodes), out_node=5,activation="sigmoid", out_activation="softmax",
  #                 num.round=rounds, array.batch.size=batch, learning.rate=lr, momentum=mom, 
  #                 eval.metric=mx.metric.accuracy)
  
for(est in estaciones){

    fichEscalado = paste("Resultados/NO2CC/escalado/esc_",est,"_",contam,".csv",sep="")
    fichModelo = paste("Resultados/NO2CC/modelos/mod_",est,"_",contam,sep="")
    fichSalida = paste("Resultados/NO2CC/Estudios predicciones/ficheros/fich_",est,"_",contam,".csv",sep="")
    
    
  
    escala<-function(dat,campos){
      for (col in campos){
        nueZ <- paste(col,"Z",sep="")
        escalado<-scale(as.numeric(dat[,col]),center = T,scale = T)   # escala los valores
        dat[nueZ]<-escalado
        # guardar valores de escalado en dataframe para luego persistirlos
        colcen <- paste(col,"_CEN",sep="")
        colsca <- paste(col,"_SCA",sep="")
        dtEscalado[dtEscalado$cont==contam,colcen]<-attr(escalado, "scaled:center")
        dtEscalado[dtEscalado$cont==contam,colsca]<-attr(escalado, "scaled:scale")

      }        
        write.table(dtEscalado, fichEscalado,row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")
        
    
      
      return(dat)
    }
    
    
    # lectura fichero datos
    if (file.exists(fich)){
    dtDatos<-readr::read_delim(fich,delim=";",col_names = T )
    # cuento ocurrencias de cada clas# e 
    # clases<-dtDatos %>% group_by(valorcat) %>% summarise(count=n())
    # cuento ocurrencias de cada clas# e por estacion
    # clasesEstacion<-dtDatos %>% group_by(estacion,valorcat) %>% summarise(count=n())
    
    #Selecciono registros de la estaci�n y elimino valores extremos clase 5
    
    # elimina extremos dtDatosE<-as.data.frame(dtDatos[dtDatos$estacion==est & dtDatos$valorcat<5,])
    dtDatosE<-as.data.frame(dtDatos[dtDatos$estacion==est,])
    
    #dtDatosE<-as.data.frame(dtDatosE[dtDatosE$valor<120,])
    
  
    
    
    if (nrow(dtDatosE)>0){
    
    dtDatosE <- mutate(dtDatosE,
                       valor1=lag(valor,n=1),
                      tmed1=lag(tmed,n=1),
                      vmed1=lag(vmed,n=1),
                      lluvia1=lag(lluvia,n=1),
                     intensidad1=lag(intensidad,n=1))
    #                  valorant=lag(valorcat,n=1)) equivale al valor1
    
    # elimino la primera fila con nulos en los campos del registro anterior
    dtDatosE<-dtDatosE[-1,]
    
    # write.table(dtDatosE, "resultados/csv/NO2Estacion.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")
    
    dtDatosE<-escala(dtDatosE,colscalar)
    
    
    
    clasesEstacion<-dtDatosE %>% group_by(estacion,valorcat) %>% summarise(count=n())
    
    
    dtZ<-cbind(dtDatosE[,grep("Z$",colnames(dtDatosE))],dtDatosE[,grep("^valorant",colnames(dtDatosE))],valorcat=dtDatosE[,"valorcat"])
    dtComprueba<-cbind(dtZ,valor=dtDatosE[,"valor"])
    
    write.table(dtComprueba, fichSalida,row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")
    
    colcat<-grep("valorcat",colnames(dtZ))
    
    # para que las particiones sean las mismas
    set.seed(1)
    indices<-sample(1:nrow(dtZ),round(0.75*nrow(dtZ)))
    
    train<-dtZ[indices,]
    test<-dtZ[-indices,]
    
    # --------------- escribo test en fichero para pruebas
    
   # write.table(test, "resultados/test.csv",row.names = F, col.names=T,quote=F,append=F,sep=";",dec=".")
    
    # ------------------------------------
    
    require(mxnet)
    
    
    train.x <- data.matrix(train[,-colcat])
    train.y <- train[,colcat]
    test.x <- data.matrix(test[,-colcat])
    test.y <- test[,colcat]
    
    
    mx.set.seed(1)
    model <- mx.mlp(train.x, train.y, hidden_node=c(nodes), out_node=5,activation=act, out_activation="softmax",
                    num.round=rounds, array.batch.size=batch, learning.rate=lr, momentum=mom, 
                    eval.metric=mx.metric.accuracy)
   #                 epoch.end.callback=mx.callback.save.checkpoint(fichModelo))
    
    mx.model.save(model,fichModelo,rounds)
   
    clasesTest<-test %>% group_by(valorcat) %>% summarise(count=n())
    #test 
    preds <- predict(model,test.x)
    predicted_labels <- max.col(t(preds)) -1
    accu <- sum(test.y==predicted_labels)/length(test.y)
    
    
    # dim(preds)
    resul<-as.data.frame(cbind(test.x,test.y,predicted_labels))
    resul$acierto<- resul$test.y==resul$predicted_labels
    print(sprintf("**** Estaci�n: %s --- Contaminante: %s ",est,contam))
    print(sprintf("Nodos: %i Vueltas:%i  Activ: %s",nodes,rounds,act))
    print(sprintf("LR: %f Mom: %f",lr,mom))
    print(paste0("Accurracy=",accu))
    print(sprintf("Aciertos:%i  Fallos:%i",nrow(resul[resul$acierto==T,]),nrow(resul[resul$acierto==F,])))
    print(table(resul$test.y,resul$predicted_labels))
    
    # data <- mx.symbol.Variable("data")
    # fc1 <- mx.symbol.FullyConnected(data, num_hidden=12)
    # act1 <- mx.symbol.Activation(fc1, name="relu1", act_type="relu")
    # # fc2 <- mx.symbol.FullyConnected(act1, name="fc2", num_hidden=64)
    # # act2 <- mx.symbol.Activation(fc2, name="relu2", act_type="relu") 
    # fc3 <- mx.symbol.FullyConnected(act2, name="fc3", num_hidden=2)
    # lro <- mx.symbol.SoftmaxOutput(fc3, name="sm") 
    # model2 <- mx.model.FeedForward.create(lro, X=train.x, y=train.y, 
    #         ctx=mx.cpu(), num.round=100, array.batch.size=15, learning.rate=0.07, momentum=0.9)
    
    }
    
    } 
     
  }

}
sink ()
# file.show("Resultados/NO2CC/salida.txt")

# unlink("Resultados/salida.txt")
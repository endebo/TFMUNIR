rm(list=ls())


contaminantes <- c("01","06","07","08","09","10","14")
contam<-14
contamlit <- "O3"

estac<-"28079008"
tbDatos <-  read.delim("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/MEMORIA/Graficos/Datosdiarios/valores.txt",
                       header=TRUE, sep=";", na.strings="NA", strip.white=TRUE,stringsAsFactors = F)

tbDatos<- subset(tbDatos, subset=estacion==estac)
tbDatos<- subset(tbDatos, subset=contaminante==contam)
tbDatos$valor <- as.numeric(tbDatos$valor)
graphics.off()
# par(fig=c(0,0.9,0,1),new=T)
tit<-paste("Valores de ", contamlit)
subtit<-"10/09/2017 a 16/09/2017"



# plot(tbDatos$fecha,tbDatos$valor,type="o",pch=10,yaxt="n",ylim=c(0,15),
#      xlab="dia",ylab="valor", main=tit,col="darkblue")
# axis(2,at=seq(1,13,1),las=1) SO2
# plot(tbDatos$fecha,tbDatos$valor,type="o",pch=10,yaxt="n",ylim=c(0,1),
#      xlab="dia",ylab="valor", main=tit,col="darkblue")
# axis(2,at=seq(0,1,0.1),las=1) CO
# plot(tbDatos$fecha,tbDatos$valor,type="o",pch=10,yaxt="n",ylim=c(0,50),
#      xlab="dia",ylab="valor", main=tit,col="darkblue")
# axis(2,at=c(seq(0,50,5)),las=1) NO
# plot(tbDatos$fecha,tbDatos$valor,type="o",pch=10,yaxt="n",ylim=c(0,80),
#      xlab="dia",ylab="valor", main=tit,col="darkblue")
# axis(2,at=c(seq(0,80,10)),las=1) NO2
# plot(tbDatos$fecha,tbDatos$valor,type="o",pch=10,yaxt="n",ylim=c(0,11),
#      xlab="dia",ylab="valor", main=tit,col="darkblue")
# axis(2,at=c(seq(0,11,1)),las=1) pm25
# plot(tbDatos$fecha,tbDatos$valor,type="o",pch=10,yaxt="n",ylim=c(5,18),
#      xlab="dia",ylab="valor", main=tit,col="darkblue")
# axis(2,at=c(seq(5,18,1)),las=1) pm10
plot(tbDatos$fecha,tbDatos$valor,type="o",pch=10,yaxt="n",ylim=c(10,70),
     xlab="dia",ylab="valor", main=tit,col="darkblue")
axis(2,at=c(seq(10,70,10)),las=1) 

estac<-"28079018"
tbDatos <-  read.delim("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/MEMORIA/Graficos/Datosdiarios/valores.txt",
                       header=TRUE, sep=";", na.strings="NA", strip.white=TRUE,stringsAsFactors = F)

tbDatos<- subset(tbDatos, subset=estacion==estac)
tbDatos<- subset(tbDatos, subset=contaminante==contam)
tbDatos$valor <- as.numeric(tbDatos$valor)
# par(fig=c(0,0.9,0,1),new=T)
tit<-paste("Estacion ", estac, " - Contaminante ", contamlit)
subtit<-"10/09/2017 a 16/09/2017"
lines(tbDatos$fecha,tbDatos$valor,type="o",col="red",pch=10)

estac<-"28079024"
tbDatos <-  read.delim("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/MEMORIA/Graficos/Datosdiarios/valores.txt",
                       header=TRUE, sep=";", na.strings="NA", strip.white=TRUE,stringsAsFactors = F)

tbDatos<- subset(tbDatos, subset=estacion==estac)
tbDatos<- subset(tbDatos, subset=contaminante==contam)
tbDatos$valor <- as.numeric(tbDatos$valor)
# par(fig=c(0,0.9,0,1),new=T)
tit<-paste("Estacion ", estac, " - Contaminante ", contamlit)
subtit<-"10/09/2017 a 16/09/2017"
lines(tbDatos$fecha,tbDatos$valor,type="o",col="green",pch=10)

estac<-"28079038"
tbDatos <-  read.delim("C:/GONZALO/UNIR/MASTER BIGDATA/2 CUATRIMESTRE/TRABAJO FIN MASTER/MEMORIA/Graficos/Datosdiarios/valores.txt",
                       header=TRUE, sep=";", na.strings="NA", strip.white=TRUE,stringsAsFactors = F)

tbDatos<- subset(tbDatos, subset=estacion==estac)
tbDatos<- subset(tbDatos, subset=contaminante==contam)
tbDatos$valor <- as.numeric(tbDatos$valor)
# par(fig=c(0,0.9,0,1),new=T)
tit<-paste("Estacion ", estac, " - Contaminante ", contamlit)
subtit<-"10/09/2017 a 16/09/2017"
lines(tbDatos$fecha,tbDatos$valor,type="o",col="blue",pch=10)
